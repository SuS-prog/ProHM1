public class Counter {
	private static int count = 0;
	public synchronized void increment(){
		count++;

	}
	public synchronized int getValue(){
		return count;
	}
}
